package shishiriyer.runners;

import processing.awt.PSurfaceAWT;
import processing.core.PApplet;
import processing.core.PSurface;
import shishiriyer.battleship.GameBoard;
import shishiriyer.battleship.Player;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;

public class BattleShip extends PApplet {
    private Player p1, p2;
    private boolean boardSet, turn;
    private int gameOver;
    private static JFrame frame;

    public static void main(String[] args) {
        frame = new JFrame("Battleship");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        BattleShip game = new BattleShip();
        PSurface ps = game.initSurface();
        ps.setSize(1200, 600);
        PSurfaceAWT.SmoothCanvas smoothCanvas = (PSurfaceAWT.SmoothCanvas) ps.getNative();

        frame.add(smoothCanvas);
        frame.setSize(1200, 600);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        ps.startThread();
    }

    public BattleShip() {
        p1 = new Player(false);
        p2 = new Player(true);
        boardSet = false;

        while(p2.getShipBoard().getNumShips() < 5) p2.placeShip(0, 0, 0, 0, 0);
    }

    public void draw() {
        if(gameOver == 0) {
            p1.getShipBoard().draw(this, 0, 0, width / 2, height);
            p1.getHitBoard().draw(this, width / 2, 0, width / 2, height);
            strokeWeight(5);
            line(width / 2f, 0, width / 2f, height);
            strokeWeight(1);
            if (boardSet) {
                if(!turn) {
                    int status = p2.guess((int) (Math.random() * 10), (int) (Math.random() * 10), p1);
                    while (status == 0) status = p2.guess((int) (Math.random() * 10), (int) (Math.random() * 10), p1);

                    if (status == 2) turn = !turn;
                }

                GameBoard grid1 = p1.getShipBoard();
                GameBoard grid2 = p2.getShipBoard();
                boolean containsShip1 = false;
                boolean containsShip2 = false;

                for(int i = 0; i < 10; i++) {
                    for(int j = 0; j < 10; j++) {
                        if(grid1.getContents(i, j) == GameBoard.SHIP) containsShip1 = true;
                        if(grid2.getContents(i, j) == GameBoard.SHIP) containsShip2 = true;
                    }
                }

                if(!containsShip1) gameOver = 2;
                if(!containsShip2) gameOver = 1;
            }
        } else {
            JOptionPane.showMessageDialog(null,"PLAYER " + gameOver + " WINS");
            noLoop();
            frame.setVisible(false);
            frame.dispose();
            System.exit(0);
        }
    }

    public void mouseClicked() {
        if(!boardSet) {
            Point p = p1.getShipBoard().clickToIndex(new Point(mouseX, mouseY), 0, 0, width / 2, height);
            if (p.x < 10 && p.y < 10 && p.x >= 0 && p.y >= 0) p1.getShipBoard().setGridSpace(GameBoard.SHIP, p.x, p.y);
        } else {
            Point p = p1.getHitBoard().clickToIndex(new Point(mouseX, mouseY), width / 2, 0, width / 2, height);
            if(p.x < 10 && p.y < 10 && p.x >= 0 && p.y >= 0 && turn) {
                int status = p1.guess(p.x, p.y, p2);
                if(status == 2) turn = !turn;
            }
        }
    }

    public void keyPressed() {
        if(keyCode == KeyEvent.VK_ENTER) {
            boardSet = true;
            turn = true;
        } else if(keyCode == KeyEvent.VK_C) p1.getShipBoard().clear();
        else if(keyCode == KeyEvent.VK_H) {
            File f = new File("data/battleship_instructions.txt");

            if(!Desktop.isDesktopSupported()) {
                JOptionPane.showMessageDialog(null, "It looks like your desktop isn't supported.");
                return;
            }

            Desktop d = Desktop.getDesktop();
            if(f.exists()) {
                try {
                    d.open(f);
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Something went wrong.");
                }
            }
        }
    }
}