package shishiriyer.battleship;

import processing.core.PApplet;

import java.awt.*;
import java.util.ArrayList;

public class GameBoard {
    private char[][] grid;
    public static final char EMPTY = 'E';
    public static final char SHIP = 'S';
    public static final char HIT = 'X';
    public static final char MISS = 'O';
    private ArrayList<Integer> shipLengths;
    private boolean isShips;

    public GameBoard(boolean isShips) {
        grid = new char[10][10];
        shipLengths = new ArrayList<>();
        this.isShips = isShips;

        for(int i = 0; i < 10; i++) {
            for(int j = 0; j < 10; j++) {
                grid[i][j] = EMPTY;
            }
        }
    }

    public int getNumShips() {
        return shipLengths.size();
    }

    public boolean placeShip(int xDirection, int yDirection, int length, int x, int y) {
        if(x >= 0 && y >= 0 && x < 10 && y < 10) {
            int x1 = x + xDirection * length;
            int y1 = y + yDirection * length;

            for(int i = 0; i < length; i++) {
                // System.out.println(grid[x + xDirection * i][y] + " " + grid[x][y + yDirection * i]);
                if(!(x1 >= 0 && y1 >= 0 && x1 < 10 && y1 < 10 && grid[x + xDirection * i][y] != SHIP && grid[x][y + yDirection * i] != SHIP)) {
                    return false;
                }
            }

            shipLengths.add(length);
            for(int i = 0; i < length; i++) {
                grid[x + xDirection * i][y] = SHIP;
                grid[x][y + yDirection * i] = SHIP;
            }

            return approveShip(length);
        }

        return false;
    }

    /* public boolean checkStatus(int x, int y) {
        return grid[x][y] == SHIP;
    } */

    public char getContents(int x, int y) {
        return grid[x][y];
    }

    public void setGridSpace(char c, int x, int y) {
        grid[x][y] = c;
    }

    public boolean approveShip(int length) {
        int carriers = 0;
        int battleships = 0;
        int subs = 0;
        int destroyers = 0;

        for(int i = 0; i < shipLengths.size(); i++) {
            int shipLength = shipLengths.get(i);
            if(shipLength == 5) carriers++;
            else if(shipLength == 4) battleships++;
            else if(shipLength == 3) subs++;
            else destroyers++;
        }

        if(length == 5 && carriers == 1) return false;
        if(length == 4 && battleships == 1) return false;
        if(length == 3 && subs == 2) return false;
        return !(length == 2 && destroyers == 1);
    }

    public void draw(PApplet p, int x, int y, int w, int h) {
        if(isShips) p.fill(125);
        else p.fill(255, 192, 56);

        for(int i = 0; i < 10; i++) {
            for(int j = 0; j < 10; j++) {
                if(grid[i][j] == SHIP || grid[i][j] == 's') p.fill(190);
                else if(grid[i][j] == HIT) p.fill(255, 0, 0);
                else if(grid[i][j] == MISS) p.fill(255);
                else {
                    if(isShips) p.fill(125);
                    else p.fill(255, 192, 56);
                }

                p.rect(w * j / 10f + x, h * i / 10f + y, w / 10f, h / 10f);
            }
        }
    }

    public Point clickToIndex(Point p, int x, int y, int w, int h) {
        return new Point(10 * (p.y - y) / h, 10 * (p.x - x) / w);
    }

    public void clear() {
        for(int i = 0; i < 10; i++) {
            for(int j = 0; j < 10; j++) {
                grid[i][j] = EMPTY;
            }
        }
    }
}