package shishiriyer.battleship;

public class Player {
    private GameBoard ships;
    private GameBoard hitsAndMisses;
    private boolean computer;

    public Player(boolean computer) {
        this.computer = computer;
        ships = new GameBoard(true);
        hitsAndMisses = new GameBoard(false);
    }

    public void placeShip(int xDirection, int yDirection, int length, int x, int y) {
        if(!computer && ships.placeShip(xDirection, yDirection, length, x, y)) return;
        else {
            int[][] combinations = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
            int combination = (int)(Math.random() * 4);
            xDirection = combinations[combination][0];
            yDirection = combinations[combination][1];
            length = (int)(Math.random() * 4) + 2;
            x = (int)(Math.random() * 10);
            y = (int)(Math.random() * 10);

            // System.out.println(x + " " + y);

            ships.placeShip(xDirection, yDirection, length, x, y);
        }
    }

    public int guess(int x, int y, Player p) {
        if(hitsAndMisses.getContents(x, y) != GameBoard.HIT && hitsAndMisses.getContents(x, y) != GameBoard.MISS) {
            if(p.ships.getContents(x, y) == GameBoard.SHIP) {
                hitsAndMisses.setGridSpace(GameBoard.HIT, x, y);
                p.getShipBoard().setGridSpace(GameBoard.HIT, x, y);
                return 1;
            } else {
                hitsAndMisses.setGridSpace(GameBoard.MISS, x, y);
                p.getShipBoard().setGridSpace(GameBoard.MISS, x, y);
                return 2;
            }
        }

        return 0;
    }

    public GameBoard getShipBoard() {
        return ships;
    }

    public GameBoard getHitBoard() {
        return hitsAndMisses;
    }
}